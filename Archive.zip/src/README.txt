Recreate the image recreate.PNG using the tools that you know (CSS, HTML, JS).

Bonus points for accomplishing this task with the following:
- React optionally using https://reactjs.org/docs/create-a-new-react-app.html to make it easier.
- using github to send it back to us.
- using a CSS in JS solution.