import React from "react";
import "./MayLike.css";

class MayLike extends React.Component {
  render(){
    return(
      <div className= "line-container">
        <h1 className="line-title">You May Like</h1>
        <div className="line"></div>
      </div>
    )
  }

}

export default MayLike;